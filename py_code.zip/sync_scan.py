"""
Brute-force scan: maximum synchronization length L(w) for cyclic words.
Verifies D_max = p-2 and that L=p is never achievable.

Run: python sync_scan.py
"""
from itertools import product
import time
from typing import Dict, List, Tuple


def sync_length(w: List[int]) -> int:
    """Compute L(w): minimal future window length for synchronization."""
    p = len(w)
    for L in range(1, p + 1):
        bucket: Dict[Tuple[int, ...], int] = {}
        ok = True
        for i in range(p):
            b = tuple(w[(i + t) % p] for t in range(1, L + 1))
            cur = w[i]
            if b in bucket:
                if bucket[b] != cur:
                    ok = False
                    break
            else:
                bucket[b] = cur
        if ok:
            return L
    return p


def brute_force_max_L(m: int, p: int) -> Tuple[int, int, str, bool]:
    """
    Enumerate all words of length p over alphabet {0..m-1}.
    Returns (L_max, D_max, best_word_str, any_L_equals_p).
    """
    best_L = 0
    best_w = [0] * p
    found_L_eq_p = False

    for w_tuple in product(range(m), repeat=p):
        w = list(w_tuple)
        L = sync_length(w)
        if L == p:
            found_L_eq_p = True
        if L > best_L:
            best_L = L
            best_w = w[:]

    return best_L, best_L - 1, "".join(str(x) for x in best_w), found_L_eq_p


def single_marker_check(p: int) -> int:
    """Verify L(000...01) = p-1 for a single-marker word."""
    w = [0] * (p - 1) + [1]
    return sync_length(w)


if __name__ == "__main__":
    print("=" * 70)
    print("MAXIMUM SYNCHRONIZATION LENGTH SCAN")
    print("=" * 70)

    # ── Part 1: Full enumeration for small p ──
    for label, m, max_p in [("m=2 (binary)", 2, 15), ("m=3 (ternary)", 3, 10)]:
        print(f"\n{'─' * 50}")
        print(f" {label}")
        print(f"{'─' * 50}")
        print(f"{'p':>4} {'L_max':>6} {'D_max':>6} {'D=p-2':>6} {'L=p?':>6}  best_word")

        for p in range(2, max_p + 1):
            t0 = time.time()
            L_max, D_max, best_w, found_Lp = brute_force_max_L(m, p)
            elapsed = time.time() - t0

            eq_check = "YES" if D_max == p - 2 else "NO"
            lp_check = "YES" if found_Lp else "NO"

            print(f"{p:>4} {L_max:>6} {D_max:>6} {eq_check:>6} {lp_check:>6}  {best_w}  ({elapsed:.1f}s)")

            if elapsed > 60:
                print("  (stopping due to time)")
                break

    # ── Part 2: Single-marker verification for large p ──
    print(f"\n{'─' * 50}")
    print(f" Single-marker word 000...01 verification")
    print(f"{'─' * 50}")
    print(f"{'p':>4} {'L':>6} {'L=p-1?':>8}")

    for p in range(2, 30):
        L = single_marker_check(p)
        ok = "YES" if L == p - 1 else "NO"
        print(f"{p:>4} {L:>6} {ok:>8}")

    print("\nDone.")
