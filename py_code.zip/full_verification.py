"""
Complete verification of the entire theory chain.
Checks every theorem, lemma, construction, and numerical claim.
"""
import math
from itertools import product
from collections import Counter, defaultdict
import random

print("=" * 70)
print("FULL THEORY VERIFICATION")
print("=" * 70)

# =====================================================================
# CHECK 1: Lemma 1 - F is bijection (reversibility) for general g
# =====================================================================
print("\n[CHECK 1] F is bijection for general g, a in Z_m*")
print("-" * 50)

def F_map(x, m, a, g_func):
    """F(x^(0),...,x^(k)) = (x^(1),...,x^(k), a*x^(0)+g(x^(1),...,x^(k))) mod m"""
    k = len(x) - 1
    new_last = (a * x[0] + g_func(x[1:])) % m
    return tuple(x[1:]) + (new_last,)

def F_inv(u, m, a, g_func):
    """Inverse: x^(i) = u^(i-1) for i>=1, x^(0) = a^{-1}(u^(k) - g(u^(0),...,u^(k-1))) mod m"""
    k = len(u) - 1
    a_inv = pow(a, -1, m)
    x0 = (a_inv * (u[k] - g_func(u[:k]))) % m
    return (x0,) + tuple(u[:k])

passed = True
for m in [2, 3, 5, 7]:
    for k in [1, 2, 3]:
        # pick a in Z_m*
        a = 1
        for candidate in range(2, m):
            if math.gcd(candidate, m) == 1:
                a = candidate
                break
        
        # random g function (use a lookup table)
        g_table = {}
        for args in product(range(m), repeat=k):
            g_table[args] = random.randint(0, m-1)
        g_func = lambda args, gt=g_table: gt[tuple(args)]
        
        # check F is bijection: F(F_inv(u)) == u for all u
        X = list(product(range(m), repeat=k+1))
        images = set()
        for x in X:
            fx = F_map(x, m, a, g_func)
            images.add(fx)
            # check inverse
            recovered = F_inv(fx, m, a, g_func)
            if recovered != x:
                print(f"  FAIL: m={m}, k={k}, a={a}, x={x}, F(x)={fx}, F_inv(F(x))={recovered}")
                passed = False
        if len(images) != len(X):
            print(f"  FAIL: m={m}, k={k} - F is not surjective ({len(images)} images vs {len(X)} states)")
            passed = False

print(f"  Result: {'PASS' if passed else 'FAIL'} - F is bijection for all tested (m,k,a,g)")

# =====================================================================
# CHECK 2: Window recurrence formula Y_{t+k+1} = a*Y_t + g(Y_{t+1},...,Y_{t+k})
# =====================================================================
print("\n[CHECK 2] Window recurrence formula (Lemma 4)")
print("-" * 50)

passed = True
for m in [2, 3, 5]:
    for k in [1, 2, 3]:
        a = 1
        for candidate in range(2, m):
            if math.gcd(candidate, m) == 1:
                a = candidate
                break
        
        g_table = {}
        for args in product(range(m), repeat=k):
            g_table[args] = random.randint(0, m-1)
        g_func = lambda args, gt=g_table: gt[tuple(args)]
        
        # pick random initial state, run trajectory
        X = list(product(range(m), repeat=k+1))
        for trial in range(20):
            s = list(X[random.randint(0, len(X)-1)])
            s = tuple(s)
            
            # generate trajectory of length k+5
            traj = [s]
            for t in range(k + 5):
                s = F_map(s, m, a, g_func)
                traj.append(s)
            
            # Y_t = x_t^(0)
            Y = [traj[t][0] for t in range(len(traj))]
            
            # check: Y[t+k+1] == (a * Y[t] + g(Y[t+1],...,Y[t+k])) mod m
            for t in range(len(Y) - k - 1):
                lhs = Y[t + k + 1]
                rhs = (a * Y[t] + g_func(tuple(Y[t+1:t+k+1]))) % m
                if lhs != rhs:
                    print(f"  FAIL: m={m}, k={k}, t={t}: Y[t+k+1]={lhs} != a*Y[t]+g(...)={rhs}")
                    passed = False

print(f"  Result: {'PASS' if passed else 'FAIL'} - Window recurrence holds for all tested cases")

# =====================================================================
# CHECK 3: Microscopic state = (Y_t, Y_{t+1}, ..., Y_{t+k})
# =====================================================================
print("\n[CHECK 3] Microscopic state equivalence s_t = (Y_t,...,Y_{t+k})")
print("-" * 50)

passed = True
for m in [2, 3, 5]:
    for k in [1, 2, 3]:
        a = 1
        for candidate in range(2, m):
            if math.gcd(candidate, m) == 1:
                a = candidate
                break
        
        g_table = {}
        for args in product(range(m), repeat=k):
            g_table[args] = random.randint(0, m-1)
        g_func = lambda args, gt=g_table: gt[tuple(args)]
        
        X = list(product(range(m), repeat=k+1))
        for s0 in X:
            s = s0
            traj = [s]
            for t in range(k + 3):
                s = F_map(s, m, a, g_func)
                traj.append(s)
            
            Y = [traj[t][0] for t in range(len(traj))]
            
            # check s_t == (Y_t, Y_{t+1}, ..., Y_{t+k}) for each t
            for t in range(len(traj) - k):
                s_t = traj[t]
                y_window = tuple(Y[t:t+k+1])
                if s_t != y_window:
                    print(f"  FAIL: m={m}, k={k}, t={t}: s_t={s_t} != Y_window={y_window}")
                    passed = False

print(f"  Result: {'PASS' if passed else 'FAIL'} - State equivalence holds")

# =====================================================================
# CHECK 4: I_k = H(Y_t | Y_{t+1:t+k}) for the residue window system
# =====================================================================
print("\n[CHECK 4] I_k = H(Y_t | Y_{t+1:t+k}) identity (Theorem 3)")
print("-" * 50)

def compute_entropy(counts):
    """Compute entropy from a Counter of observations."""
    total = sum(counts.values())
    if total == 0:
        return 0.0
    h = 0.0
    for c in counts.values():
        if c > 0:
            p = c / total
            h -= p * math.log2(p)
    return h

def compute_joint_entropy(samples):
    """Compute H(X) from list of tuples."""
    counts = Counter(samples)
    return compute_entropy(counts)

def compute_cond_MI(Z_list, W_list, U_list):
    """
    Compute I(U; Z | W) = H(U,W) + H(Z,W) - H(W) - H(U,W,Z)
    Z = Y_t, W = Y_{t+1:t+k}, U = Y_{t+k+1}
    """
    UW = [(u, w) for u, w in zip(U_list, W_list)]
    ZW = [(z, w) for z, w in zip(Z_list, W_list)]
    UWZ = [(u, w, z) for u, w, z in zip(U_list, W_list, Z_list)]
    
    H_UW = compute_joint_entropy(UW)
    H_ZW = compute_joint_entropy(ZW)
    H_W = compute_joint_entropy(W_list)
    H_UWZ = compute_joint_entropy(UWZ)
    
    return H_UW + H_ZW - H_W - H_UWZ

def compute_cond_entropy(X_list, Y_list):
    """Compute H(X|Y) = H(X,Y) - H(Y)"""
    XY = list(zip(X_list, Y_list))
    return compute_joint_entropy(XY) - compute_joint_entropy(Y_list)

passed = True
# Use exact enumeration (uniform over all states)
for m in [2, 3, 5]:
    for k in [1, 2, 3]:
        if m**k > 500:
            continue
        a = 1
        for candidate in range(2, m):
            if math.gcd(candidate, m) == 1:
                a = candidate
                break
        
        # g = 0 (simplest case)
        g_func = lambda args, m_=m: 0
        
        X_all = list(product(range(m), repeat=k+1))
        
        # For each initial state, generate trajectory and collect samples
        Z_samples = []  # Y_t
        W_samples = []  # (Y_{t+1},...,Y_{t+k})
        U_samples = []  # Y_{t+k+1}
        
        for s0 in X_all:
            s = s0
            traj = [s]
            for t in range(k + 2):
                s = F_map(s, m, a, g_func)
                traj.append(s)
            Y = [traj[t][0] for t in range(len(traj))]
            
            # take t=0
            Z_samples.append(Y[0])
            W_samples.append(tuple(Y[1:k+1]))
            U_samples.append(Y[k+1])
        
        I_k = compute_cond_MI(Z_samples, W_samples, U_samples)
        H_cond = compute_cond_entropy(Z_samples, W_samples)
        
        diff = abs(I_k - H_cond)
        ok = diff < 1e-10
        if not ok:
            print(f"  FAIL: m={m}, k={k}: I_k={I_k:.6f}, H(Y_t|W)={H_cond:.6f}, diff={diff:.2e}")
            passed = False

print(f"  Result: {'PASS' if passed else 'FAIL'} - I_k = H(Y_t | Y_{{t+1:t+k}}) identity verified")

# =====================================================================
# CHECK 5: Numerical example m=3, k=2, a=2, g(y1,y2)=y1+2*y2
# =====================================================================
print("\n[CHECK 5] Specific example: m=3, k=2, a=2, g=y1+2y2")
print("-" * 50)

m, k, a = 3, 2, 2
g_func = lambda args, m_=3: (args[0] + 2*args[1]) % m_

X_all = list(product(range(m), repeat=k+1))

# Verify F is bijection
images = set()
for x in X_all:
    images.add(F_map(x, m, a, g_func))
print(f"  |X| = {len(X_all)}, |F(X)| = {len(images)}, bijection = {len(images) == len(X_all)}")

# Generate long trajectory from each state, compute I_0, I_1, I_2, I_3
for test_k in range(4):
    Z_s, W_s, U_s = [], [], []
    for s0 in X_all:
        s = s0
        traj = [s]
        for t in range(test_k + 3):
            s = F_map(s, m, a, g_func)
            traj.append(s)
        Y = [traj[t][0] for t in range(len(traj))]
        Z_s.append(Y[0])
        if test_k > 0:
            W_s.append(tuple(Y[1:test_k+1]))
        else:
            W_s.append(())
        U_s.append(Y[test_k+1])
    
    I_val = compute_cond_MI(Z_s, W_s, U_s)
    print(f"  I_{test_k} = {I_val:.6f} bits", end="")
    if test_k == 2:
        expected = math.log2(3)
        print(f"  (expected log2(3) = {expected:.6f}, match = {abs(I_val - expected) < 1e-6})")
    else:
        print(f"  (expected ~0, is_zero = {I_val < 1e-10})")

# =====================================================================
# CHECK 6: Sync length L(w) definition and computation
# =====================================================================
print("\n[CHECK 6] Sync length computation correctness")
print("-" * 50)

def future_block(w, i, L):
    p = len(w)
    return tuple(w[(i + t) % p] for t in range(1, L + 1))

def sync_length(w):
    p = len(w)
    for L in range(1, p + 1):
        bucket = {}
        ok = True
        for i in range(p):
            b = future_block(w, i, L)
            cur = w[i]
            if b in bucket:
                if bucket[b] != cur:
                    ok = False
                    break
            else:
                bucket[b] = cur
        if ok:
            return L
    return p

# Test known cases
# Single marker: 000...01 should have L = p-1
passed = True
for p in range(2, 20):
    w = [0]*(p-1) + [1]
    L = sync_length(w)
    if L != p - 1:
        print(f"  FAIL: single marker p={p}: L={L}, expected {p-1}")
        passed = False

# All same symbol: should have L=1
for m_val in [2, 3, 5]:
    for p in range(2, 10):
        w = [0] * p
        L = sync_length(w)
        if L != 1:
            print(f"  FAIL: all-zero p={p}: L={L}, expected 1")
            passed = False

# de Bruijn-ish: alternating 0101... should have small L
w = [0, 1] * 5  # p=10
L = sync_length(w)
print(f"  Alternating 0101...(p=10): L={L}")

print(f"  Result: {'PASS' if passed else 'FAIL'} - Sync length computation correct")

# =====================================================================
# CHECK 7: D_max = p-2 claim - exhaustive verification
# =====================================================================
print("\n[CHECK 7] D_max = p-2 exhaustive verification")
print("-" * 50)

passed = True
for m_val in [2, 3]:
    max_p = 13 if m_val == 2 else 8
    for p in range(2, max_p + 1):
        best_L = 0
        best_w = None
        for w_tuple in product(range(m_val), repeat=p):
            w = list(w_tuple)
            L = sync_length(w)
            if L > best_L:
                best_L = L
                best_w = w[:]
        
        expected_L = p - 1
        expected_D = p - 2
        actual_D = best_L - 1
        ok = (best_L == expected_L)
        if not ok:
            print(f"  FAIL: m={m_val}, p={p}: L_max={best_L} (expected {expected_L}), best_w={''.join(str(x) for x in best_w)}")
            passed = False
        else:
            print(f"  m={m_val}, p={p}: L_max={best_L}, D_max={actual_D} = p-2 ✓  best_w={''.join(str(x) for x in best_w)}")

print(f"  Result: {'PASS' if passed else 'FAIL'} - D_max = p-2 verified exhaustively")

# =====================================================================
# CHECK 8: L=p never achievable
# =====================================================================
print("\n[CHECK 8] L=p never achievable (exhaustive)")
print("-" * 50)

passed = True
for m_val in [2, 3]:
    max_p = 13 if m_val == 2 else 8
    for p in range(2, max_p + 1):
        found = False
        for w_tuple in product(range(m_val), repeat=p):
            w = list(w_tuple)
            L = sync_length(w)
            if L == p:
                print(f"  FOUND L=p: m={m_val}, p={p}, w={''.join(str(x) for x in w)}")
                found = True
                passed = False
                break
        if not found:
            pass  # good

print(f"  Result: {'PASS' if passed else 'FAIL'} - L=p never achieved for all tested (m,p)")

# =====================================================================
# CHECK 9: Finite system D < infinity proof logic
# =====================================================================
print("\n[CHECK 9] Finite permutation system => periodic => D finite")
print("-" * 50)

passed = True
for m_val in [2, 3]:
    for k in [1, 2]:
        if m_val**(k+1) > 100:
            continue
        a = 1
        for candidate in range(2, m_val):
            if math.gcd(candidate, m_val) == 1:
                a = candidate
                break
        g_func = lambda args, m_=m_val: 0
        
        X_all = list(product(range(m_val), repeat=k+1))
        
        # Check every orbit is periodic
        for s0 in X_all:
            visited = set()
            s = s0
            steps = 0
            while s not in visited:
                visited.add(s)
                s = F_map(s, m_val, a, g_func)
                steps += 1
                if steps > len(X_all) + 1:
                    print(f"  FAIL: orbit not closing for m={m_val}, k={k}, s0={s0}")
                    passed = False
                    break
        
        # Check max cycle length
        visited_global = set()
        max_cycle = 0
        for s0 in X_all:
            if s0 in visited_global:
                continue
            orbit = []
            s = s0
            while s not in visited_global:
                visited_global.add(s)
                orbit.append(s)
                s = F_map(s, m_val, a, g_func)
            # find cycle length
            if s in orbit:
                cycle_start = orbit.index(s)
                cycle_len = len(orbit) - cycle_start
                max_cycle = max(max_cycle, cycle_len)
        
        print(f"  m={m_val}, k={k}: |X|={len(X_all)}, max_cycle={max_cycle}, D_upper_bound={max_cycle-1}")

print(f"  Result: {'PASS' if passed else 'FAIL'} - All orbits periodic, D bounded")

# =====================================================================
# CHECK 10: Upper bound I_k <= log(m)
# =====================================================================
print("\n[CHECK 10] I_k <= log2(m) upper bound")
print("-" * 50)

passed = True
for m_val in [2, 3, 5]:
    for k in [1, 2, 3]:
        if m_val**(k+1) > 200:
            continue
        a = 1
        for candidate in range(2, m_val):
            if math.gcd(candidate, m_val) == 1:
                a = candidate
                break
        
        # Try several g functions
        for trial in range(5):
            g_table = {}
            for args in product(range(m_val), repeat=k):
                g_table[args] = random.randint(0, m_val-1)
            g_func = lambda args, gt=g_table: gt[tuple(args)]
            
            X_all = list(product(range(m_val), repeat=k+1))
            Z_s, W_s, U_s = [], [], []
            for s0 in X_all:
                s = s0
                traj = [s]
                for t in range(k + 2):
                    s = F_map(s, m_val, a, g_func)
                    traj.append(s)
                Y = [traj[t][0] for t in range(len(traj))]
                Z_s.append(Y[0])
                W_s.append(tuple(Y[1:k+1]))
                U_s.append(Y[k+1])
            
            I_val = compute_cond_MI(Z_s, W_s, U_s)
            bound = math.log2(m_val)
            if I_val > bound + 1e-10:
                print(f"  FAIL: m={m_val}, k={k}: I_k={I_val:.6f} > log2(m)={bound:.6f}")
                passed = False

print(f"  Result: {'PASS' if passed else 'FAIL'} - I_k <= log2(m) always holds")

# =====================================================================
# SUMMARY
# =====================================================================
print("\n" + "=" * 70)
print("VERIFICATION SUMMARY")
print("=" * 70)
print("""
CHECK 1:  F bijection (reversibility)          - general g
CHECK 2:  Window recurrence formula             - Lemma 4
CHECK 3:  State = observation window            - structural observation
CHECK 4:  I_k = H(Y_t | window) identity       - Theorem 3
CHECK 5:  Specific example m=3,k=2             - numerical values
CHECK 6:  Sync length computation              - L(w) correctness
CHECK 7:  D_max = p-2 exhaustive               - main numerical claim
CHECK 8:  L=p never achievable                 - impossibility claim
CHECK 9:  Finite system => periodic => D finite - structural theorem
CHECK 10: I_k <= log(m) upper bound            - information bound
""")
