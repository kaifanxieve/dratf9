"""
Verify the information conservation law: S = H(Y0)
and the telescoping identity: I_k = Phi_k - Phi_{k+1}

For any binary cyclic word w under uniform phase:
  sum_{k=0}^{p-2} I_k = H(Y_0) <= 1 bit

Run: python conservation_check.py
"""
import math
from itertools import product
from typing import Dict, List, Tuple


def sync_length(w: List[int]) -> int:
    p = len(w)
    for L in range(1, p + 1):
        bucket: Dict[Tuple[int, ...], int] = {}
        ok = True
        for i in range(p):
            b = tuple(w[(i + t) % p] for t in range(1, L + 1))
            if b in bucket and bucket[b] != w[i]:
                ok = False
                break
            bucket[b] = w[i]
        if ok:
            return L
    return p


def I_k_periodic_bits(w: List[int], k: int) -> float:
    p = len(w)
    counts: Dict[Tuple[int, Tuple[int, ...], int], int] = {}
    for t in range(p):
        z = w[t]
        ctx = tuple(w[(t + i) % p] for i in range(1, k + 1))
        u = w[(t + k + 1) % p]
        key = (z, ctx, u)
        counts[key] = counts.get(key, 0) + 1

    c_ctx: Dict[Tuple[int, ...], int] = {}
    c_zctx: Dict[Tuple[int, Tuple[int, ...]], int] = {}
    c_uctx: Dict[Tuple[int, Tuple[int, ...]], int] = {}
    for (z, ctx, u), v in counts.items():
        c_ctx[ctx] = c_ctx.get(ctx, 0) + v
        c_zctx[(z, ctx)] = c_zctx.get((z, ctx), 0) + v
        c_uctx[(u, ctx)] = c_uctx.get((u, ctx), 0) + v

    I = 0.0
    for (z, ctx, u), v in counts.items():
        p_j = v / p
        p_c = c_ctx[ctx] / p
        p_zc = c_zctx[(z, ctx)] / p
        p_uc = c_uctx[(u, ctx)] / p
        I += p_j * math.log2((p_j * p_c) / (p_zc * p_uc))
    return max(I, 0.0)


def Phi_cond_entropy(w: List[int], k: int) -> float:
    """Phi_k = H(Y0 | Y1..Yk) in bits."""
    p = len(w)
    cnt_y0_ctx: Dict[Tuple[int, Tuple[int, ...]], int] = {}
    cnt_ctx: Dict[Tuple[int, ...], int] = {}
    for t in range(p):
        y0 = w[t]
        ctx = tuple(w[(t + i) % p] for i in range(1, k + 1))
        cnt_y0_ctx[(y0, ctx)] = cnt_y0_ctx.get((y0, ctx), 0) + 1
        cnt_ctx[ctx] = cnt_ctx.get(ctx, 0) + 1

    H = 0.0
    for (y0, ctx), v in cnt_y0_ctx.items():
        p_y0_ctx = v / p
        p_ctx = cnt_ctx[ctx] / p
        p_cond = p_y0_ctx / p_ctx
        H += p_y0_ctx * (-math.log2(p_cond))
    return max(H, 0.0)


def check_word(bitstring: str) -> None:
    w = [int(c) for c in bitstring.strip()]
    p = len(w)
    L = sync_length(w)

    Ik = [I_k_periodic_bits(w, k) for k in range(p - 1)]
    Phis = [Phi_cond_entropy(w, k) for k in range(p)]
    diffs = [Phis[k] - Phis[k + 1] for k in range(p - 1)]

    S = sum(Ik)
    H0 = Phis[0]

    # Check telescoping
    max_tele_err = max(abs(Ik[k] - diffs[k]) for k in range(p - 1))
    # Check conservation
    cons_err = abs(S - H0)

    print("=" * 60)
    print(f"w = {bitstring}")
    print(f"p = {p}, L = {L}, D = {L - 1}")
    print(f"ones = {sum(w)}, density = {sum(w)/p:.4f}")
    print()
    print("Ik:", [f"{x:.4f}" for x in Ik])
    print("Phi:", [f"{x:.4f}" for x in Phis])
    print("dPhi:", [f"{x:.4f}" for x in diffs])
    print()
    print(f"sum Ik = {S:.10f}")
    print(f"H(Y0)  = {H0:.10f}")
    print(f"Conservation error: {cons_err:.2e}")
    print(f"Telescope max error: {max_tele_err:.2e}")
    print()
    if cons_err < 1e-9 and max_tele_err < 1e-9:
        print("PASS: Conservation S = H(Y0) and telescoping I_k = Phi_k - Phi_{k+1}")
    else:
        print("ISSUES detected.")
    print(f"Bound check: S = {S:.6f} <= log2(2) = 1.000000 ?  {'YES' if S <= 1.0 + 1e-9 else 'NO'}")
    print("=" * 60)
    print()


def maximise_S_under_maxD(p: int) -> Tuple[float, str]:
    """Find word maximizing S subject to D = p-2."""
    best_S = -1.0
    best_w = "0" * p
    for tail in product([0, 1], repeat=p - 1):
        w = [0] + list(tail)
        L = sync_length(w)
        if L != p - 1:
            continue
        S = sum(I_k_periodic_bits(w, k) for k in range(p - 1))
        if S > best_S:
            best_S = S
            best_w = "".join(str(x) for x in w)
    return best_S, best_w


if __name__ == "__main__":
    print("PART 1: Verify conservation identity for specific words\n")

    check_word("001")
    check_word("001010010101")
    check_word("0010101001010101")
    check_word("000000000001")

    print("\nPART 2: Find S-maximizing words under D=p-2 constraint\n")
    for p in [3, 6, 8, 10, 12]:
        S, w = maximise_S_under_maxD(p)
        print(f"p={p:>3}: best S = {S:.6f}, w = {w}, "
              f"ones = {sum(int(c) for c in w)}, "
              f"density = {sum(int(c) for c in w)/p:.3f}")

    print("\nPART 3: Conservation holds for ALL words (spot check)\n")
    for p in [5, 7, 9, 11]:
        all_ok = True
        count = 0
        for tail in product([0, 1], repeat=p - 1):
            w = [0] + list(tail)
            S = sum(I_k_periodic_bits(w, k) for k in range(p - 1))
            H0 = Phi_cond_entropy(w, 0)
            if abs(S - H0) > 1e-9:
                all_ok = False
                break
            count += 1
        print(f"p={p}: checked {count} words, all satisfy S = H(Y0): {all_ok}")

    print("\nDone.")
