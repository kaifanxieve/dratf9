#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
02_control_experiments.py  —  Isolate the projection mechanism
===============================================================
Paper: Projection-Induced Non-Markovianity in Deterministic Residual Rotation Systems

Tests four gating modes and compares I₂(ω) vs I₂(x) where x_t = (ω_t, u_t):

    all0      u_t ≡ 0        pure irrational rotation, no external driving
    all1      u_t ≡ 1        different pure rotation
    bernoulli u_t ~ B(p)     i.i.d. random gating
    periodic  u_t = [0,0,1,0] repeating

Key findings (Section 5 of paper):
  • I₂(ω) > 0 for all0  →  stochastic forcing not necessary
  • I₂(x) ≈ I₂(ω)       →  memory does not vanish when u_t is observed;
                             it lives in the coarse-graining, not in hidden driving

Usage
-----
    python 02_control_experiments.py
    python 02_control_experiments.py --alpha 9.8696 --gamma 1.0472 --m 20:300:5 --T 200000
    python 02_control_experiments.py --modes all0,bernoulli --seeds 0,1,2 --out results.csv
"""
from __future__ import annotations
import argparse, csv, math
import numpy as np
from shared import simulate_gated, i2_bits


MODES = ['all0', 'all1', 'bernoulli', 'periodic']


def run(alpha, gamma, m_vals, T, modes, seeds, p, out):
    fieldnames = ['mode', 'm', 'seed', 'a_alpha', 'a_gamma',
                  'I2_omega', 'I2_x', 'delta_I2']
    rows = []

    for mode in modes:
        for m in m_vals:
            a_alpha = (m * alpha / (2 * math.pi)) % 1.0
            a_gamma = (m * gamma / (2 * math.pi)) % 1.0
            for seed in seeds:
                omega, u_seq = simulate_gated(alpha, gamma, m, T,
                                              mode=mode, p=p, seed=seed)
                i2_om = i2_bits(omega)

                # augmented observation x_t = omega_t * 2 + u_t
                x_aug = omega.astype(np.int64) * 2 + u_seq.astype(np.int64)
                i2_x  = i2_bits(x_aug)
                delta  = i2_x - i2_om

                rows.append({
                    'mode': mode, 'm': m, 'seed': seed,
                    'a_alpha': round(a_alpha, 6), 'a_gamma': round(a_gamma, 6),
                    'I2_omega': round(i2_om, 6),
                    'I2_x':    round(i2_x,  6),
                    'delta_I2': round(delta, 6),
                })
                print(f"{mode:10s}  m={m:4d}  seed={seed}  "
                      f"I2_ω={i2_om:.4f}  I2_x={i2_x:.4f}  Δ={delta:+.4f}")

    with open(out, 'w', newline='') as f:
        csv.DictWriter(f, fieldnames=fieldnames).writeheader()
        csv.DictWriter(f, fieldnames=fieldnames).writerows(rows)
    print(f"\nSaved {len(rows)} rows → {out}")

    # ── summary ──
    print(f"\n{'─'*55}")
    print(f"  {'Mode':<12} {'mean I2_ω':>10} {'mean Δ':>10}  {'I2_ω>0 (%)':>10}")
    print(f"{'─'*55}")
    for mode in modes:
        sub = [r for r in rows if r['mode'] == mode]
        vals   = [r['I2_omega'] for r in sub]
        deltas = [r['delta_I2'] for r in sub]
        frac   = 100 * sum(1 for v in vals if v > 1e-4) / len(vals)
        print(f"  {mode:<12} {np.mean(vals):>10.4f} {np.mean(deltas):>+10.4f}  {frac:>9.1f}%")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--alpha',  type=float, default=math.pi**2,
                    help='Rotation step α (radians). Default: π²')
    ap.add_argument('--gamma',  type=float, default=math.pi / 3,
                    help='Gate step γ (radians). Default: π/3')
    ap.add_argument('--m',      type=str,   default='20:300:10',
                    help='Scales: "start:end:step" or comma list. Default: 20:300:10')
    ap.add_argument('--T',      type=int,   default=200_000,
                    help='Simulation length. Default: 200,000')
    ap.add_argument('--modes',  type=str,   default=','.join(MODES),
                    help='Comma-separated modes. Default: all four')
    ap.add_argument('--seeds',  type=str,   default='0,1,2',
                    help='Comma-separated seeds. Default: 0,1,2')
    ap.add_argument('--p',      type=float, default=0.25,
                    help='Bernoulli probability. Default: 0.25')
    ap.add_argument('--out',    type=str,   default='results_control.csv',
                    help='Output CSV. Default: results_control.csv')
    args = ap.parse_args()

    def parse_m(s):
        if ':' in s:
            parts = s.split(':')
            a, b = int(parts[0]), int(parts[1])
            step = int(parts[2]) if len(parts) > 2 else 1
            return list(range(a, b + 1, step))
        return [int(x) for x in s.split(',')]

    m_vals = parse_m(args.m)
    modes  = [s.strip() for s in args.modes.split(',')]
    seeds  = [int(s)    for s in args.seeds.split(',')]

    print(f"α={args.alpha:.4f}  γ={args.gamma:.4f}  "
          f"T={args.T:,}  scales={len(m_vals)}  modes={modes}\n")
    run(args.alpha, args.gamma, m_vals, args.T, modes, seeds, args.p, args.out)


if __name__ == '__main__':
    main()
