# Projection-Induced Non-Markovianity — Code Package
## Paper: *Projection-Induced Non-Markovianity in Deterministic Residual Rotation Systems*

---

## System

```
x_{t+1} = (x_t + beta) mod 1          [irrational rotation]
omega_t  = floor(m * x_t)              [coarse-graining at scale m]
c_t      = 1{ r_t >= 1 - a(m) }       [carry process,  r_t = {m x_t},  a(m) = {m beta}]
```

---

## Files

| File | Theorem | Description |
|------|---------|-------------|
| `shared.py`                  | —         | Shared simulation and estimation utilities (imported by all scripts) |
| `01_proof_verification.py`   | 1 & 2     | Verify conditional probabilities; Weyl equidistribution check |
| `02_control_experiments.py`  | —         | Four gating modes; isolate projection from external driving |
| `03_sturmian_verification.py`| 3         | Sturmian properties: p(n)=n+1, unique right-special, Myhill-Nerode |
| `04_markov_order_scan.py`    | —         | Scan I_k over m; produce k*(m) plots (overflow-safe byte-key method) |

**Requirements:** Python 3.8+, NumPy only.

---

## Quick start

### Theorem 1  (Table in Section 3.3)
```bash
python 01_proof_verification.py --beta 9.8696 --m 6 --T 2000000
```
Expected output:
```
P(c_{t+1}=1 | c_t=1)              = 0.000000  [theory 0]
P(c_{t+1}=1 | c_{t-1}=1, c_t=0)  = 0.000000  [theory 0]
P(c_{t+1}=1 | c_{t-1}=0, c_t=0)  = 0.385352  [theory 0.385352]
✓  Theorem 1 verified
```

### Theorem 2  (Table in Section 4.4, L=3)
```bash
python 01_proof_verification.py --beta 9.8696 --m 7 --L 3 --T 3000000
```
Expected output:
```
P(c_{t+1}=1 | E1)  = 0.000000  [theory 0]
P(c_{t+1}=1 | E0)  = 0.154707  [theory 0.154707]
✓  Theorem 2 verified (L=3)
```

### Theorem 3  (Appendix C)
```bash
python 03_sturmian_verification.py --beta 9.8696 --m 6 --T 500000 --nmax 14
```
Expected output:
```
p(n) = n+1 for all n in [1,14]:  ✓  YES
Unique right-special word per length:  ✓  YES
F(u_n) ≠ F(non-RS) at every length:   ✓  YES
✓  THEOREM 3 CONFIRMED  —  infinite Markov order at m=6
```

### Control experiments  (Section 5)
```bash
python 02_control_experiments.py --alpha 9.8696 --gamma 1.0472 --T 200000
```

### Markov order scan  (Section 6, Figures 1–3)
```bash
python 04_markov_order_scan.py --alpha 9.8696 --m 20:400 --T 300000 --Kmax 10 --carry --out scan.csv
```

---

## Key parameters

| Symbol | Default | Meaning |
|--------|---------|---------|
| `beta` | π²      | Rotation step (normalized, β = α/2π) |
| `alpha`| π²      | Rotation step in radians |
| `gamma`| π/3     | Gate step in radians (gated model only) |
| `m`    | 6       | Coarse-graining scale |
| `T`    | varies  | Simulation length |
| `L`    | 1       | Markov order depth for Theorem 2 |

---

## Theorems and conditions

### Theorem 1 — Existence of non-Markovianity
**Condition:** `a(m) = {m·beta} ∈ (0, 1/3)`

*For any irrational β, infinitely many m satisfy this (Weyl equidistribution).*

Conditional probabilities proven:
- P(c_{t+1}=1 | c_t=1) = 0
- P(c_{t+1}=1 | c_t=0, c_{t-1}=1) = 0
- P(c_{t+1}=1 | c_t=0, c_{t-1}=0) = **a / (1−2a)** > 0

### Theorem 2 — Unbounded Markov order across scales
**Condition:** `a(m) < 1/(L+3)`

*For any L ≥ 1, infinitely many m satisfy this.*

Conditional probabilities proven:
- P(c_{t+1}=1 | E₁: c_{t−L−1}=1, L+1 zeros) = 0
- P(c_{t+1}=1 | E₀: c_{t−L−1}=0, L+1 zeros) = **a / (1−(L+2)a)** > 0

### Theorem 3 — Infinite Markov order at fixed scale
**Condition:** `a(m) ∉ ℚ` (irrational)

*By Weyl equidistribution, this holds for a set of full density of m.*

Proof via Sturmian sequence theory:
1. `{c_t}` is a Sturmian sequence: `p(n) = n+1`
2. Exactly one right-special word per length
3. Infinitely many distinct follower classes (Myhill-Nerode)
4. Factor language non-regular → subshift not sofic → infinite Markov order
5. Bijection c_t ↔ ω_t transfers the result to `{ω_t}`

---

## Notes on numerical precision

- `04_markov_order_scan.py` uses exact byte-key (void-key) hashing to avoid int64
  overflow when packing joint count tables for large m and k.
- All I_k estimates converge for T ≥ 200,000 over the tested parameter ranges.
- Sturmian verification (`03_sturmian_verification.py`) is reliable for n ≤ 16
  with T ≥ 500,000.
