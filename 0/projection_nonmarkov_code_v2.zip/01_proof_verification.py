#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
01_proof_verification.py  —  Verify Theorems 1 & 2
====================================================
Paper: Projection-Induced Non-Markovianity in Deterministic Residual Rotation Systems

Theorem 1  (condition: a(m) < 1/3)
    P(c_{t+1}=1 | c_t=1)               = 0
    P(c_{t+1}=1 | c_t=0, c_{t-1}=1)   = 0
    P(c_{t+1}=1 | c_t=0, c_{t-1}=0)   = a/(1-2a)

Theorem 2  (condition: a(m) < 1/(L+3))
    P(c_{t+1}=1 | E1: c_{t-L-1}=1, c_{t-L..t}=0)  = 0
    P(c_{t+1}=1 | E0: c_{t-L-1}=0, c_{t-L..t}=0)  = a / (1-(L+2)*a)

Usage
-----
    python 01_proof_verification.py
    python 01_proof_verification.py --L 3 --T 3000000
    python 01_proof_verification.py --beta 9.8696 --m 7 --L 3 --T 3000000
"""
from __future__ import annotations
import argparse, math
import numpy as np
from shared import simulate_omega, residual_step, recover_carry, i2_bits


def find_m_for_L(beta: float, L: int, m_range=range(2, 500)):
    """Find smallest m with 0.01 < a(m) < 1/(L+3)."""
    thresh = 1.0 / (L + 3)
    for m in m_range:
        a = (m * beta) % 1.0
        if 0.01 < a < thresh:
            return m, a
    return None, None


def cond_prob(c: np.ndarray, history: list[int]) -> tuple[float, int]:
    """P(c_{t+1}=1 | c_{t-n+1..t} = history).  history[-1] is c_t."""
    n = len(history)
    N = len(c) - n
    if N <= 0:
        return float('nan'), 0
    mask = np.ones(N, dtype=bool)
    for j, val in enumerate(history):
        mask &= (c[j:j+N] == val)
    count = int(mask.sum())
    if count == 0:
        return float('nan'), 0
    return float((c[n:][mask] == 1).mean()), count


def verify_theorem1(c: np.ndarray, a: float) -> bool:
    print(f"\n{'─'*58}")
    print(f"  THEOREM 1   condition: a < 1/3 = {1/3:.4f}")
    print(f"  a = {a:.6f}   met: {a < 1/3}")
    print(f"{'─'*58}")
    theory_B = a / (1 - 2*a)
    p11,  n11 = cond_prob(c, [1])
    pA,   nA  = cond_prob(c, [1, 0])
    pB,   nB  = cond_prob(c, [0, 0])
    print(f"  P(c_{{t+1}}=1 | c_t=1)              = {p11:.6f}  [theory 0]          N={n11}")
    print(f"  P(c_{{t+1}}=1 | c_{{t-1}}=1, c_t=0) = {pA:.6f}  [theory 0]          N={nA}")
    print(f"  P(c_{{t+1}}=1 | c_{{t-1}}=0, c_t=0) = {pB:.6f}  [theory {theory_B:.6f}]  N={nB}")
    ok = abs(p11) < 1e-5 and abs(pA) < 1e-5 and abs(pB - theory_B) / theory_B < 0.005
    print(f"\n  {'✓  Theorem 1 verified' if ok else '✗  Discrepancy'}")
    return ok


def verify_theorem2(c: np.ndarray, a: float, L: int) -> bool:
    thresh   = 1.0 / (L + 3)
    theory_E0 = a / (1 - (L+2)*a)
    print(f"\n{'─'*58}")
    print(f"  THEOREM 2   L={L},  condition: a < 1/{L+3} = {thresh:.4f}")
    print(f"  a = {a:.6f}   met: {a < thresh}")
    print(f"{'─'*58}")
    zeros = [0] * (L + 1)
    pE1, nE1 = cond_prob(c, [1] + zeros)
    pE0, nE0 = cond_prob(c, [0] + zeros)
    print(f"  P(c_{{t+1}}=1 | E1)  = {pE1:.6f}  [theory 0]            N={nE1}")
    print(f"  P(c_{{t+1}}=1 | E0)  = {pE0:.6f}  [theory {theory_E0:.6f}]  N={nE0}")
    if math.isnan(pE1) or math.isnan(pE0):
        print("  ✗  Insufficient data — increase --T")
        return False
    ok = abs(pE1) < 1e-5 and abs(pE0 - theory_E0) / (theory_E0 + 1e-12) < 0.01
    print(f"\n  {'✓  Theorem 2 verified (L=' + str(L) + ')' if ok else '✗  Discrepancy'}")
    return ok


def weyl_check(beta: float) -> None:
    print(f"\n{'─'*58}")
    print(f"  WEYL EQUIDISTRIBUTION CHECK  (m in [2,10000])")
    print(f"{'─'*58}")
    for L in [1, 2, 3, 5, 10]:
        thresh = 1.0 / (L + 3)
        frac = sum(1 for m in range(2, 10001) if (m*beta) % 1.0 < thresh) / 9999
        print(f"  L={L:2d}:  threshold=1/{L+3}={thresh:.4f}  measured={frac:.4f}  expected≈{thresh:.4f}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--beta', type=float, default=math.pi**2)
    ap.add_argument('--m',    type=int,   default=None,
                    help='Scale m. Auto-selected if omitted.')
    ap.add_argument('--T',    type=int,   default=2_000_000)
    ap.add_argument('--L',    type=int,   default=1,
                    help='Order L for Theorem 2. Default: 1')
    args = ap.parse_args()

    beta = args.beta
    L    = args.L
    print(f"β = {beta:.6f}   T = {args.T:,}   L = {L}\n")

    # ── Theorem 1 ──────────────────────────────────────────────────────
    m1 = args.m
    if m1 is None:
        m1, a1 = find_m_for_L(beta, L=1)
        if m1 is None:
            raise RuntimeError("No m found with a(m) < 1/3")
        print(f"Auto-selected m={m1} (a={a1:.6f}) for Theorem 1")
    else:
        _, a1 = residual_step(beta, m1)

    omega1 = simulate_omega(beta, m1, args.T)
    k1, _  = residual_step(beta, m1)
    c1     = recover_carry(omega1, m1, k1)
    bij = np.all(((omega1[1:].astype(np.int64) - omega1[:-1].astype(np.int64) - k1) % m1)
                 == c1.astype(np.int64))
    print(f"Bijection carry↔ω  m={m1}: {'✓' if bij else '✗'}")
    i2 = i2_bits(omega1)
    print(f"I₂(ω)  m={m1}: {i2:.6f} bits  {'> 0 ✓' if i2 > 1e-6 else '≈ 0'}")

    if a1 < 1/3:
        verify_theorem1(c1, a1)
    else:
        print(f"\nNote: a={a1:.4f} ≥ 1/3  (Theorem 1 condition not met for m={m1})")

    # ── Theorem 2 ──────────────────────────────────────────────────────
    m2 = args.m
    if m2 is None:
        m2, a2 = find_m_for_L(beta, L=L)
        if m2 is None:
            raise RuntimeError(f"No m found with a(m) < 1/{L+3}")
        if m2 != m1:
            print(f"\nAuto-selected m={m2} (a={a2:.6f}) for Theorem 2 (L={L})")
            omega2 = simulate_omega(beta, m2, args.T)
            k2, _  = residual_step(beta, m2)
            c2     = recover_carry(omega2, m2, k2)
        else:
            c2, a2 = c1, a1
    else:
        _, a2 = residual_step(beta, m2)
        c2    = c1

    if a2 < 1.0 / (L + 3):
        verify_theorem2(c2, a2, L)
    else:
        print(f"\nNote: a={a2:.4f} ≥ 1/{L+3}  (Theorem 2 condition not met for L={L})")

    weyl_check(beta)


if __name__ == '__main__':
    main()
