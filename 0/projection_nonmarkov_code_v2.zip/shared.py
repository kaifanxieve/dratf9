#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
shared.py  —  Common simulation and estimation utilities
========================================================
Paper: Projection-Induced Non-Markovianity in Deterministic Residual Rotation Systems

All scripts in this package import from here.

Changelog (v2 — post peer review):
  - factor_complexity: fixed off-by-one (range end was len-n, now len-n+1)
  - recover_carry: replaced silent np.clip with hard ValueError on non-binary diff
  - i2_bits: added alphabet-size guard (K > 50000 raises ValueError)
  - simulate_omega: added docstring note on time-index convention
"""
from __future__ import annotations
import math
import numpy as np

LN2 = math.log(2.0)


# ── Simulation ────────────────────────────────────────────────────────────────

def simulate_omega(beta: float, m: int, T: int, x0: float = 0.123456789) -> np.ndarray:
    """
    Simulate the coarse-grained irrational rotation.

        x_{t+1} = (x_t + beta) mod 1
        omega[t] = floor(m * x_{t+1})

    Note on time indexing: omega is recorded *after* the rotation update.
    This is a one-step forward shift relative to the convention omega_t = floor(m x_t).
    All stationary statistics (I_k, Markov order) are unaffected because the process
    is stationary.

    Returns array of shape (T,) with dtype int32.
    """
    x = x0 % 1.0
    omega = np.empty(T, dtype=np.int32)
    for t in range(T):
        x = (x + beta) % 1.0
        omega[t] = min(int(m * x), m - 1)
    return omega


def residual_step(beta: float, m: int) -> tuple[int, float]:
    """Return (k, a) where m*beta = k + a,  a = {m*beta} in [0,1)."""
    val = m * beta
    k   = int(math.floor(val))
    a   = val - k
    return k, max(0.0, min(a, 1.0 - 1e-15))


def recover_carry(omega: np.ndarray, m: int, k_m: int) -> np.ndarray:
    """
    Recover the binary carry sequence from consecutive omega values.

        c_t = (omega_{t+1} - omega_t - k_m) mod m   in {0, 1}

    Returns array of shape (T-1,) with dtype int8.

    Raises ValueError if any recovered value is outside {0, 1}.
    (Silently clipping would hide logic errors or floating-point drift.)
    """
    diff = (omega[1:].astype(np.int64) - omega[:-1].astype(np.int64) - k_m) % m
    bad  = np.where((diff != 0) & (diff != 1))[0]
    if bad.size:
        raise ValueError(
            f"recover_carry: non-binary values at {bad.size} positions "
            f"(first: idx={bad[0]}, value={diff[bad[0]]}). "
            f"Check m={m}, k_m={k_m}."
        )
    return diff.astype(np.int8)


def simulate_gated(alpha: float, gamma: float, m: int, T: int,
                   mode: str, p: float = 0.25,
                   seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """
    Simulate the gated system:

        x_{t+1} = (x_t + alpha + u_t * gamma) mod 1
        omega_t  = floor(m * x_t)

    mode: 'all0' | 'all1' | 'bernoulli' | 'periodic'
    Returns (omega, u_seq).
    """
    rng = np.random.default_rng(seed)
    if mode == 'all0':
        u_seq = np.zeros(T, dtype=np.int8)
    elif mode == 'all1':
        u_seq = np.ones(T, dtype=np.int8)
    elif mode == 'bernoulli':
        u_seq = rng.binomial(1, p, size=T).astype(np.int8)
    elif mode == 'periodic':
        pat   = np.array([0, 0, 1, 0], dtype=np.int8)
        u_seq = np.tile(pat, (T // 4) + 1)[:T]
    else:
        raise ValueError(f"Unknown gating mode: {mode!r}")

    x     = 0.123456789
    omega = np.empty(T, dtype=np.int32)
    for t in range(T):
        x        = (x + alpha + u_seq[t] * gamma) % 1.0
        omega[t] = min(int(m * x), m - 1)
    return omega, u_seq


# ── Information-theoretic estimators ─────────────────────────────────────────

def i2_bits(seq: np.ndarray) -> float:
    """
    Estimate I(s_{t-1}; s_{t+1} | s_t) in bits via exact joint counting.

    Uses int64 packing: key = A + K*B + K^2*C.
    Safe when K^3 < 2^63, i.e. K < ~2.1e6.  In practice K = m or 2m,
    so this is fine for all scales studied in the paper.

    Raises ValueError if K > 50000 (use the void-key estimator in
    04_markov_order_scan.py for very large alphabets).
    """
    seq = np.asarray(seq)
    if len(seq) < 3:
        return 0.0
    _, inv = np.unique(seq, return_inverse=True)
    s = inv.astype(np.int64)
    K = int(s.max()) + 1

    if K > 50000:
        raise ValueError(
            f"i2_bits: alphabet size K={K} > 50000. "
            "Use the void-key estimator in 04_markov_order_scan.py."
        )

    A, B, C = s[:-2], s[1:-1], s[2:]
    N = len(A)

    def cnt(k):
        u, c = np.unique(k, return_counts=True)
        return dict(zip(u.tolist(), c.tolist()))

    c3   = cnt(A + K * B + K * K * C)
    c_ab = cnt(A + K * B)
    c_bc = cnt(B + K * C)
    c_b  = cnt(B)

    total = 0.0
    for key, cf in c3.items():
        a2 = key % K
        b2 = (key // K) % K
        c2 = key // (K * K)
        total += (cf / N) * (
            math.log(cf) + math.log(c_b[b2])
            - math.log(c_ab[a2 + K * b2])
            - math.log(c_bc[b2 + K * c2])
        )
    return max(total / LN2, 0.0)


def factor_complexity(seq: np.ndarray, n_max: int) -> dict[int, int]:
    """
    Return p(n) = number of distinct length-n factors, for n = 1..n_max.

    Valid start positions: i = 0, 1, ..., len(seq)-n  (inclusive).
    Total window count = len(seq) - n + 1.

    Note: the previous version used range(len(seq)-n) which missed the last
    window; this is now corrected to range(len(seq)-n+1).
    """
    result = {}
    for n in range(1, n_max + 1):
        words = set()
        for i in range(len(seq) - n + 1):  # +1: include last window
            words.add(seq[i:i + n].tobytes())
        result[n] = len(words)
    return result


def right_special_words(seq: np.ndarray, n: int) -> list[bytes]:
    """
    Return all right-special words of length n.

    A word w is right-special if both w+'0' and w+'1' appear as
    length-(n+1) factors.  We need seq[i+n] to exist, so valid start
    positions are i = 0..len(seq)-n-1, i.e. range(len(seq)-n).
    """
    ext0, ext1 = set(), set()
    for i in range(len(seq) - n):
        w = seq[i:i + n].tobytes()
        if seq[i + n] == 0:
            ext0.add(w)
        else:
            ext1.add(w)
    return list(ext0 & ext1)
