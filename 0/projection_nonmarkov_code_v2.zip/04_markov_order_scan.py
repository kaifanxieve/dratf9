#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markov order scan for coarse-grained irrational rotation (overflow-safe).

System:
  x_{t+1} = (x_t + beta) mod 1
  omega_t = floor(m x_t)

We compute conditional mutual informations:
  I_k = I(omega_{t-k}; omega_{t+1} | omega_{t-k+1..t})
for k = 1..Kmax, in bits.

Key fix vs v1:
  - Avoid int64 packing overflow by using exact byte-keys (np.void) for window tuples.
  - No collisions, strictly correct.

Outputs CSV:
  m, a_m, k_m, I1..IK, k_star, (optional carry I's)
"""

from __future__ import annotations
import argparse
import csv
import math
from typing import Tuple, List, Dict

import numpy as np

LN2 = math.log(2.0)


def simulate_omega(beta: float, m: int, T: int, x0: float = 0.123456789) -> np.ndarray:
    x = x0 % 1.0
    omega = np.empty(T, dtype=np.int32)
    for t in range(T):
        x = (x + beta) % 1.0
        v = int(m * x)  # floor
        if v >= m:
            v = m - 1
        omega[t] = v
    return omega


def compute_k_a(beta: float, m: int) -> Tuple[int, float]:
    A = m * beta
    k = int(math.floor(A))
    a = A - k
    if a < 0.0:
        a = 0.0
    if a >= 1.0:
        a = a % 1.0
    return k, a


def as_void_keys(M: np.ndarray) -> np.ndarray:
    """
    Convert a 2D int matrix (N, L) into 1D array of exact byte-keys (np.void),
    representing each row exactly with no overflow/collision.
    """
    if M.ndim != 2:
        raise ValueError("as_void_keys expects 2D array.")
    # Ensure contiguous
    Mc = np.ascontiguousarray(M)
    row_bytes = Mc.dtype.itemsize * Mc.shape[1]
    return Mc.view(np.dtype((np.void, row_bytes))).ravel()


def unique_count_void(keys: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    For void keys, return (unique_keys, counts, first_indices).
    first_indices gives an index into original keys for each unique key.
    """
    u, idx, c = np.unique(keys, return_index=True, return_counts=True)
    return u, c.astype(np.int64), idx.astype(np.int64)


def build_count_map(u: np.ndarray, c: np.ndarray) -> Dict[bytes, int]:
    """
    Map key-bytes -> count, for exact lookup.
    """
    mp: Dict[bytes, int] = {}
    for key, cnt in zip(u, c):
        mp[key.tobytes()] = int(cnt)
    return mp


def conditional_mutual_information_bits(seq: np.ndarray, k: int) -> float:
    """
    I_k = I(X_{t-k}; X_{t+1} | X_{t-k+1..t})
    Exact counting using byte-keys, safe for large m and k.
    """
    seq = np.asarray(seq)
    n = len(seq)
    if n < k + 2:
        return 0.0

    # Remap symbols to 0..K-1 to keep dtype small
    _, inv = np.unique(seq, return_inverse=True)
    s = inv.astype(np.int32)
    Ksym = int(s.max()) + 1

    # Build windows length L = k+2
    N = n - (k + 1)
    L = k + 2

    # Use int16 if possible else int32
    dtype = np.int16 if Ksym <= 32767 else np.int32
    W = np.empty((N, L), dtype=dtype)
    for j in range(L):
        W[:, j] = s[j:j+N]

    # Full / left / right / cond windows
    W_full = W
    W_left = W[:, : (1 + k)]          # (X_{t-k}, X_{t-k+1..t})
    W_right = W[:, 1:]                # (X_{t-k+1..t}, X_{t+1})
    if k > 0:
        W_cond = W[:, 1:(1+k)]        # (X_{t-k+1..t})
    else:
        # Not used here since k>=1 always in our scan, but keep for completeness
        W_cond = np.zeros((N, 1), dtype=dtype)

    key_full = as_void_keys(W_full)
    key_left = as_void_keys(W_left)
    key_right = as_void_keys(W_right)
    key_cond = as_void_keys(W_cond)

    u_full, c_full, idx_full = unique_count_void(key_full)
    u_left, c_left, _ = unique_count_void(key_left)
    u_right, c_right, _ = unique_count_void(key_right)
    u_cond, c_cond, _ = unique_count_void(key_cond)

    # Build lookup maps for marginals
    map_left = build_count_map(u_left, c_left)
    map_right = build_count_map(u_right, c_right)
    map_cond = build_count_map(u_cond, c_cond)

    # For each unique full key, get one representative row to derive its marginal keys exactly
    # idx_full are indices into the original windows
    reps = W_full[idx_full, :]  # shape (#unique_full, L)

    # Derive marginal representative windows
    reps_left = reps[:, : (1 + k)]
    reps_right = reps[:, 1:]
    reps_cond = reps[:, 1:(1+k)] if k > 0 else np.zeros((len(reps), 1), dtype=dtype)

    reps_left_key = as_void_keys(reps_left)
    reps_right_key = as_void_keys(reps_right)
    reps_cond_key = as_void_keys(reps_cond)

    cf = c_full.astype(np.float64)
    Nf = float(N)

    I_nat = 0.0
    for i in range(len(u_full)):
        pij = cf[i] / Nf

        cl = map_left[reps_left_key[i].tobytes()]
        cr = map_right[reps_right_key[i].tobytes()]
        cc = map_cond[reps_cond_key[i].tobytes()]

        # term = log p(full) + log p(cond) - log p(left) - log p(right)
        # in counts form:
        term = math.log(cf[i]) + math.log(cc) - math.log(cl) - math.log(cr)
        I_nat += pij * term

    I_bits = I_nat / LN2
    if I_bits < 0 and I_bits > -1e-12:
        I_bits = 0.0
    return float(I_bits)


def recover_carry_from_omega(omega: np.ndarray, m: int, k_m: int) -> np.ndarray:
    o0 = omega[:-1].astype(np.int64)
    o1 = omega[1:].astype(np.int64)
    diff = (o1 - o0 - int(k_m)) % int(m)
    # Should be 0/1 in this model; clamp just in case
    diff = np.where(diff > 1, 1, diff)
    return diff.astype(np.int8)


def parse_m(spec: str) -> List[int]:
    spec = spec.strip()
    if ":" in spec:
        parts = spec.split(":")
        if len(parts) not in (2, 3):
            raise ValueError("Bad m range syntax. Use start:end or start:end:step.")
        start = int(parts[0]); end = int(parts[1])
        step = int(parts[2]) if len(parts) == 3 else 1
        return list(range(start, end + 1, step))
    return [int(x.strip()) for x in spec.split(",") if x.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--beta", type=float, default=None, help="beta in (0,1): rotation step /2pi form.")
    ap.add_argument("--alpha", type=float, default=None, help="alpha in radians. If given, beta=alpha/(2pi).")
    ap.add_argument("--T", type=int, default=300000, help="simulation length.")
    ap.add_argument("--m", type=str, default="20:400", help="m range: '20:400' or '20:400:2' or list '20,21,...'")
    ap.add_argument("--Kmax", type=int, default=8, help="max order k for I_k (default 8).")
    ap.add_argument("--eps", type=float, default=1e-4, help="threshold bits for declaring near-zero (default 1e-4).")
    ap.add_argument("--carry", action="store_true", help="also compute I_k for carry sequence.")
    ap.add_argument("--out", type=str, default="markov_order_scan.csv", help="output CSV")
    args = ap.parse_args()

    if (args.beta is None) == (args.alpha is None):
        raise ValueError("Provide exactly one of --beta or --alpha.")

    beta = float(args.alpha) / (2.0 * math.pi) if args.alpha is not None else float(args.beta)
    beta = beta % 1.0

    m_list = parse_m(args.m)

    header = ["m", "a_m", "k_m"]
    header += [f"I{k}_omega_bits" for k in range(1, args.Kmax + 1)]
    header += ["k_star_omega"]
    if args.carry:
        header += [f"I{k}_carry_bits" for k in range(1, args.Kmax + 1)]
        header += ["k_star_carry"]

    rows = []
    for m in m_list:
        k_m, a_m = compute_k_a(beta, m)
        omega = simulate_omega(beta=beta, m=m, T=args.T)

        I_omega = []
        for k in range(1, args.Kmax + 1):
            I_omega.append(conditional_mutual_information_bits(omega, k=k))

        k_star = next((k for k, v in enumerate(I_omega, start=1) if v < args.eps), args.Kmax + 1)

        row = [m, a_m, k_m] + I_omega + [k_star]

        if args.carry:
            carry = recover_carry_from_omega(omega, m=m, k_m=k_m)
            I_c = []
            for k in range(1, args.Kmax + 1):
                I_c.append(conditional_mutual_information_bits(carry, k=k))
            k_star_c = next((k for k, v in enumerate(I_c, start=1) if v < args.eps), args.Kmax + 1)
            row += I_c + [k_star_c]

        rows.append(row)

        print(f"m={m:4d} a={a_m:.6f}  k*={k_star}  I1={I_omega[0]:.6f}  I2={I_omega[1]:.6f}")

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)

    print(f"\nSaved: {args.out}")


if __name__ == "__main__":
    main()